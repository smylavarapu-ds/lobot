var restify = require('restify');
var builder = require('botbuilder');
//var botbuilder_azure = require("botbuilder-azure");
var request = require('sync-request')
var nlu_url = 'http://localhost:7000'
var nlu_project = 'default'

var service = (message) => {
  var path = nlu_url+"/classify"
  console.log(path)
  return JSON.parse(request('POST', path, {json: {'chat':message},}).getBody('utf8'))
}
var locationDialog = require('botbuilder-location');
// Setup Restify Server
var server = restify.createServer();
server.listen(process.env.port || process.env.PORT || 3978, function () {
   console.log('%s listening to %s', server.name, server.url);
});

var problemtypes ={
  "otp": "APP",
  "extend": "dues",
  "emi": "Emi"
}

var membershipIds ={
	"ATL00001": {
		"name": "KK Jain",
		"salutation": "Mr",
		"sex": "male",
		"type": "Loan"
	},
	"YTR12398": {
		"name": "Sashi",
		"salutation": "Mr",
		"sex": "male",
		"type": "Lender"
	},
	"QWES8848": {
		"name": "Rahul",
		"salutation": "Mr",
		"sex": "male",
		"type": "Borrower"
	},
	"ABCD1234": {
		"name": "Kareena",
		"salutation": "Ms",
		"sex": "female",
		"type": "Lender"
	},
	"YKA89874": {
		"name": "Sophia",
		"salutation": "Ms",
		"sex": "female",
		"type": "Borrower"
	}
}

// Create chat connector for communicating with the Bot Framework Service
var connector = new builder.ChatConnector({
    appId: process.env.MicrosoftAppId,
    appPassword: process.env.MicrosoftAppPassword,
    openIdMetadata: process.env.BotOpenIdMetadata
});

// Listen for messages from users
server.post('/api/messages', connector.listen());

/*----------------------------------------------------------------------------------------
* Bot Storage: This is a great spot to register the private state storage for your bot.
* We provide adapters for Azure Table, CosmosDb, SQL Azure, or you can implement your own!
* For samples and documentation, see: https://github.com/Microsoft/BotBuilder-Azure
* ---------------------------------------------------------------------------------------- */

//var tableName = 'botdata';
//var azureTableClient = new botbuilder_azure.AzureTableClient(tableName, process.env['AzureWebJobsStorage']);
//var tableStorage = new botbuilder_azure.AzureBotStorage({ gzipData: false }, azureTableClient);
server.get(/.*/, restify.plugins.serveStatic({
    'directory': '.',
    'default': 'index.html'
}));
// Create your bot with a function to receive messages from the user
var bot = new builder.UniversalBot(connector);
bot.library(locationDialog.createLibrary("ArdUw7EPbwOivuZgE8hPx3EsAAcgv9EqoDlp0s7TqHgj77Okx6U4GMTbDwkcYbQU"));
var inMemoryStorage = new builder.MemoryBotStorage();
bot.set('storage', inMemoryStorage);

bot.dialog('/', [
  function (session) {
    session.userData={}
    var dt = new Date();
    var date= dt.getFullYear() + "/" + (dt.getMonth() + 1) + "/" + dt.getDate();
    session.userData.date=date
    //session.sendTyping();
    builder.Prompts.text(session, "Hello... Welcome to ATL. How can I help you?");
  },

  function (session, results) {
      session.userData.problem = results.response;
      //session.sendTyping();

      session.beginDialog('problem')

  },

  function (session, results, next) {
    //session.sendTyping();
      session.send("Will help you on this...")
	  if(session.userData.memberID){next()}
	  else{
      builder.Prompts.text(session,  "Please share your Customer ID no?");
	  }

      //builder.Prompts.choice(session, "What type of problem you are facing?", "Flat Tyre|Out Of Fuel|Battery Dead", { listStyle: builder.ListStyle.button })
  },
  function (session, results) {
    //session.sendTyping();

	  if(session.userData.memberID){}
	  else {
		  mod_response=results.response.replace(/ /g,'')
		  console.log(mod_response)
		  session.userData.memberID=mod_response
	  }
	  session.userData.memberID = session.userData.memberID.toUpperCase()
	  if(membershipIds[session.userData.memberID]){

		  var member=membershipIds[session.userData.memberID]
		  session.userData.salutation=member.salutation
		  session.userData.name=member.name
      var type=""
      if(session.userData.type&& !session.userData.type.includes("type")){
      type = session.userData.type
    }
    else{
      type =  member.type
      session.userData.type = type
    }
    
		  builder.Prompts.confirm(session, `Welcome ${member.salutation}.${member.name}, Is this for your ${type.toUpperCase()}?`)
	  }
	  else{
		  session.userData={}
		  session.endConversation("Your Customer ID is not registered with us. Thanks for contacting us!!")
	  }

  },
  function (session, results, next){
	if(!results.response){
	  session.beginDialog('getOtherPerson')
	}
    else{next()}

  },
  function (session, results, next){
	  if(session.userData.problemtype=="problem"){
      builder.Prompts.choice(session, "What type of problem you are facing?", "Payments|APP|Customer Service", { listStyle: builder.ListStyle.button })

	  }
	  else{
		  next()
	  }
  },
  function (session, results){
	  if(results.response){
	 if(results.response.entity=="OTP"){
		 session.userData.problemtype="otp"
	 }
	  if(results.response.entity=="extend"){
		 session.userData.problemtype="extend_due_date"
	 }
	  if(results.response.entity=="emi"){
		 session.userData.problemtype="emi_durations"
	 }
	  }
    var options = {
    prompt: "What was your new number ! Where are you located",
    useNativeControl: true,
    reverseGeocode: true,
    skipFavorites: false,
		skipConfirmationAsk: true,
    requiredFields:
                locationDialog.LocationRequiredFields.streetAddress |
                locationDialog.LocationRequiredFields.locality |
                locationDialog.LocationRequiredFields.region |
                locationDialog.LocationRequiredFields.postalCode |
                locationDialog.LocationRequiredFields.country
    };
    locationDialog.getLocation(session, options);
  },
  function (session, results) {
      var location = results.response;
	  session.userData.location=location
	  if(session.userData.problemtype=="otp"){
      builder.Prompts.confirm(session,"Got it... "+session.userData.salutation+"." + session.userData.name +
                  `. I have requested our Exxecutive to call you ${location.streetAddress}, ${location.locality}, ${location.region}, ${location.postalCode}, ${location.country}. Can I help you with anything else?.\n`
                );
	  }
	  if(session.userData.problemtype=="extend_due_date"){
            session.beginDialog("extensionconfirm")
	  }
	  if(session.userData.problemtype=="emi_durations"){
      builder.Prompts.confirm(session,"Got it... "+session.userData.salutation+"." + session.userData.name +
                  `. I have requested a person to take care! ${location.streetAddress}, ${location.locality}, ${location.region}, ${location.postalCode}, ${location.country}. Can I help you with anything else?.\n`
                );
	  }

  },
  function(session, results){
	  if(results.response){
			 session.userData={}
			 session.endConversation("Please say hello to start a new conversation")
		 }
		 else{
			 session.send("Thank your for contacting ATL. For confirmation your transaction history is shown below and lists down the transactions for the ATL member in the current year")
			 var receiptcard = createReceiptCard(session)
			 var msg = new builder.Message(session).addAttachment(receiptcard)
			 session.endConversation(msg)
		 }
  }
]);

bot.dialog('problem', [
    function (session, args) {
        var problem=session.userData.problem
        var nlu_response = service(problem)
		var intent = nlu_response.intent
		console.log(intent.name+","+intent.confidence)
        if((intent.name=="problem" || intent.name == "otp" || intent.name == "extend" || intent.name == "emi") && intent.confidence>0.7){
           session.userData.problemtype=intent.name
		   if (nlu_response.entities.length > 0) {
              for (var entity of nlu_response.entities) {
                   console.log(entity.entity+":"+entity.value)
                  session.userData[entity.entity] = entity.value
              }
          }
		   session.endDialog()
        }
        else{
          builder.Prompts.text(session, "Sorry.. I didn't understand!!")
        }
    },
	function (session, results) {
		session.userData.problem=results.response
	    session.replaceDialog('problem');
	}

]);

bot.dialog('getOtherPerson', [
     function(session){
		
		
		 	 builder.Prompts.text(session, "Your problem please")
		
	 },
	 function(session, results){

		 session.userData.type=results.response

		 session.endDialog()
	 }
]);

bot.dialog('otp', [
     function(session){
	    builder.Prompts.choice(session, "What is the mobile network?", "CDMA|GSM", { listStyle: builder.ListStyle.button })
	 },
	 function(session, results){
		 session.userData.fueltype=results.response.entity
		 var location= session.userData.location
		 builder.Prompts.confirm(session,"Got it... "+session.userData.salutation+"." + session.userData.name +
                  `. I have requested to solve ${results.response.entity}  ${location.country}. Can I help you with anything else?.\n`
                );
	 },
	 function(session, results){
		 if(results.response){
			 session.userData={}
			 session.endConversation("Please say hello to start a new conversation")
		 }
		 else{
		   
			 session.send("Thank your for contacting ATL. For confirmation your transaction history is shown below and lists down the transactions for the AAA member in the current year")
			 var receiptcard = createReceiptCard(session)
			 var msg = new builder.Message(session).addAttachment(receiptcard)
			 session.endConversation(msg)

		 }
	 }



]);


function createReceiptCard(session) {
    return new builder.ReceiptCard(session)
        .title('History')
        .facts([
            builder.Fact.create(session, session.userData.memberID, session.userData.salutation+"."+membershipIds[session.userData.memberID].name + ":")
        ])
        .items([
            builder.ReceiptItem.create(session, session.userData.car.toUpperCase(), problemtypes[session.userData.problemtype]+`(${session.userData.date})`),
            builder.ReceiptItem.create(session, 'AUDI A7', 'Out of Gas(2018/04/23)')
	    
        ]).buttons([
            builder.CardAction.openUrl(session, 'https://www.aaa.com/International/?area=insurance', 'Detailed History')
        ]);
}